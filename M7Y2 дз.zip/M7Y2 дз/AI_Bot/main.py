import telebot
from keras.models import load_model  # TensorFlow is required for Keras to work
from PIL import Image, ImageOps  # Install pillow instead of PIL
import numpy as np

def ai_image(image):
    
    np.set_printoptions(suppress=True)

    
    model = load_model("keras_Model.h5", compile=False)

   
    class_names = open("labels.txt", "r").readlines()

    
    data = np.ndarray(shape=(1, 224, 224, 3), dtype=np.float32)

    
    image = Image.open(image).convert("RGB")

    
    size = (224, 224)
    image = ImageOps.fit(image, size, Image.Resampling.LANCZOS)

    
    image_array = np.asarray(image)

    
    normalized_image_array = (image_array.astype(np.float32) / 127.5) - 1

    
    data[0] = normalized_image_array

    
    prediction = model.predict(data)
    index = np.argmax(prediction)
    class_name = class_names[index]
    confidence_score = prediction[0][index]


    print("Class:", class_name[2:], end="")
    print("Confidence Score:", confidence_score)
    return class_name[2:]
    
    

bot = telebot.TeleBot('7746125940:AAGI75eAmJgPKnaDuarKf30sTaSmk54NUJw')

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, "Привет! Я твой Telegram бот.")

@bot.message_handler(content_types=["photo"])
def send_image(message):
    file_info = bot.get_file(message.photo[-1].file_id)
    file_name = file_info.file_path.split('/')[-1]
    downloaded_file = bot.download_file(file_info.file_path)
    with open(file_name, 'wb') as new_file:
        new_file.write(downloaded_file)
    result = ai_image(file_name)
    bot.reply_to(message, result)

    
    

bot.polling()